import os, sys
port = sys.argv[1:]
os.system("python -m SimpleHTTPServer "+str(port))
